import React from 'react';

/**
 * Modelo de datos de un producto
 */
export interface Product {
  producto_id: string;
  nombre: string;
  description?: string;
  price?: number | string;
  category_id?: string;
  age?: string;
  gender?: string;
  type?: string;
  availability?: string;
  imageUrl?: string;
}

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  if (!product || !product.producto_id) return null;

  // Normalizar precio a número
  const rawPrice = product.price;
  const priceNum =
    typeof rawPrice === 'string'
      ? parseFloat(rawPrice)
      : rawPrice ?? 0;

  return (
    <div className="card bg-white shadow rounded-lg overflow-hidden">
      <img
        src={product.imageUrl || '/placeholder.png'}
        alt={product.nombre}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-bold mb-2">{product.nombre}</h3>
        <p className="text-gray-600 mb-4">
          {product.description || 'Sin descripción'}
        </p>
        <span className="text-xl font-semibold">
          ${priceNum.toFixed(2)}
        </span>
      </div>
    </div>
  );
};

export default ProductCard;
